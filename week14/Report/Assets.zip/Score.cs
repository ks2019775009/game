using UnityEngine;
using UnityEngine.UI;

public class Score: MonoBehaviour
{
    public Text scoreText; 
    public float scoreIncreaseInterval = 1f / 60f; 

    private int score = 0; 
    private float timer = 0f; 

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= scoreIncreaseInterval)
        {
            score++; 
            scoreText.text = "Score: " + score.ToString(); 
            timer = 0f; 
        }
    }
}
