using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SoundController : MonoBehaviour
{
    public Text buttonText;

    public void ToggleChange()
    {
        if (buttonText.text == "Sound OFF")
        {
            buttonText.text = "Sound ON";
            SoundManager.Instance.bgm.Stop(); // ���� ON
        }
        else if (buttonText.text == "Sound ON")
        {
            buttonText.text = "Sound OFF";
            SoundManager.Instance.bgm.Play(); // ���� OFF
        }
    }
}
