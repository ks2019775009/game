using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallManager : MonoBehaviour
{
    public GameObject ballPrefab; 
    public int numberOfBalls = 3; 
    public static float second = 1f;


    void Start()
    {
        StartCoroutine(SpawnBalls());
    }

    IEnumerator SpawnBalls()
    {
        for (int i = 0; i < numberOfBalls; i++)
        {
            
            GameObject ball = Instantiate(ballPrefab, GetRandomPosition(), Quaternion.identity);

            yield return new WaitForSeconds(second); 
        }
    }

    Vector3 GetRandomPosition()
    {
        
        float randomX = Random.Range(-3.5f, 6f);
        float randomY = transform.position.y;
        float randomZ = Random.Range(-6.6f, -10.8f);
        return new Vector3(randomX, randomY, randomZ);
    }
}
