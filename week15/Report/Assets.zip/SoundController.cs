using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SoundController : MonoBehaviour
{
    public Text buttonText;
    public static bool isPlaying = true; 

    public void ToggleChange()
    {
        if (buttonText.text == "Sound OFF")
        {
            buttonText.text = "Sound ON";
            isPlaying = false;
            SoundManager.Instance.bgm.Stop(); // ���� ON
        }
        else if (buttonText.text == "Sound ON")
        {
            buttonText.text = "Sound OFF";
            isPlaying = true;
            SoundManager.Instance.bgm.Play(); // ���� OFF
        }
    }
}
