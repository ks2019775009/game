using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Ball : MonoBehaviour
{
    public Rigidbody ball_Rigidbody;
    public static float speed = 500f;
    void Start()
    {
        Renderer ballRenderer = GetComponent<Renderer>();
        ballRenderer.material.color = GetRandomColor();

    float randomX = Random.Range(-3.5f, 6f); 
    Vector3 randomPosition = new Vector3(randomX, transform.position.y, transform.position.z); 
    transform.position = randomPosition; 
    
    ball_Rigidbody.AddForce(-transform.forward * speed);
    }
    Color GetRandomColor()
    {
    float randomR = Random.Range(0f, 1f);
    float randomG = Random.Range(0f, 1f);
    float randomB = Random.Range(0f, 1f);
    return new Color(randomR, randomG, randomB);
    }

    void OnCollisionEnter(Collision collision){
        if(collision.gameObject.name == "user"){
            print("you lose ! ");
            GameOver();
        }
    }
    public void GameOver(){
        SoundManager.Instance.bgm.Stop();
        SceneManager.LoadScene(2);
    }
}
