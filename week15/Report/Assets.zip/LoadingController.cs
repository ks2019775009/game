using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoadingController : MonoBehaviour
{
    public Slider progressbar;
    public Text loadtext;
    public static float btninfo = 600f;

    IEnumerator LoadScene(){
        yield return null;
        AsyncOperation operation = SceneManager.LoadSceneAsync(0);
        operation.allowSceneActivation = false;
        while(!operation.isDone){
            yield return null;
            if(progressbar.value <1f){
                progressbar.value = Mathf.MoveTowards(progressbar.value,1f,Time.deltaTime);
            }
            else{
                    Ball.speed = btninfo;    
                    operation.allowSceneActivation = true;       
                
            }
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(LoadScene());
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
