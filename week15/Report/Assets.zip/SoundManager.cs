using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance { get; private set; } // �̱��� �ν��Ͻ�

    public AudioSource bgm;
    

    private void Awake(){
        var soundManagers = FindObjectsOfType<SoundManager>();
        if( soundManagers.Length == 1){
            DontDestroyOnLoad(gameObject);
            Instance = this; // �̱��� �ν��Ͻ� ����
        }else{
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        bgm.Play();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
