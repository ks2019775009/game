using UnityEngine;
using UnityEngine.UI;

public class ButtonController : MonoBehaviour
{

    private void Start()
    {
        Button easyButton = GameObject.Find("EasyBtn").GetComponent<Button>();
        Button NormalButton = GameObject.Find("NoRBtn").GetComponent<Button>();
        Button HardButton = GameObject.Find("HardBtn").GetComponent<Button>();
        easyButton.onClick.AddListener(OnEasyButtonClick);
        NormalButton.onClick.AddListener(OnNormalButtonClick);
        HardButton.onClick.AddListener(OnHardButtonClick);
    }

    public static void OnEasyButtonClick()
    {
        LoadingController.btninfo = 600f;
        BallManager.second = 1f;
    }
    public static void OnNormalButtonClick()
    {
        LoadingController.btninfo = 1000f;
        BallManager.second = 0.6f;
    }
    public static void OnHardButtonClick()
    {
        LoadingController.btninfo = 1500f;
        BallManager.second = 0.5f;
    }
}
